var express = require('express');
//var texto = require('./modulo1');

var app = express();//executando express

app.set('view engine', 'ejs'); //mecanismo de engine a ser usado
app.set('views','./app/views'); //diretório dos arquivos locais

module.exports = app;