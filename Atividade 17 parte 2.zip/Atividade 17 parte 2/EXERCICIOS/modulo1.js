var texto = 'Observe que essa mensagem vem do módulo';
module.exports = texto; //necessário para funcionar o módulo