var texto = 'Observe que essa mensagem vem do módulo';
module.exports = texto; //é preciso acrescentar o exports para que o modulo joque a frase na tela