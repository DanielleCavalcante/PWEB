console.log('1');
t();
console.log('3');
function t(){
    console.log('2');
}